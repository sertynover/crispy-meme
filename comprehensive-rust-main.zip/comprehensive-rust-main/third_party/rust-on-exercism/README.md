# Exercism Rust Track

This directory contains exercises copied from the Exercism Rust Track. Please
see <https://github.com/exercism/rust> for the full project.

## License

The Exercism Rust Track is licensed under the MIT license ([LICENSE](LICENSE)).
