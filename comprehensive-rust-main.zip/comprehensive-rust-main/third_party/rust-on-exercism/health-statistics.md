You're working on implementing a health-monitoring system. As part of that, you
need to keep track of users' health statistics.

You'll start with some stubbed functions in an `impl` block as well as a `User`
struct definition. Your goal is to implement the stubbed out methods on the
`User` `struct` defined in the `impl` block.
