# Rust By Example

This directory contains examples copied from Rust by Example. Please see
<https://github.com/rust-lang/rust-by-example> for the full project.

## License

Rust by Example is licensed under either of

* Apache License, Version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) or
  <http://www.apache.org/licenses/LICENSE-2.0>)
* MIT license ([LICENSE-MIT](LICENSE-MIT) or
  <http://opensource.org/licenses/MIT>)

at your option.
