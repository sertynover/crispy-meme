# mdBook

This directory contains files copied from mdBook. Please see
<https://github.com/rust-lang/mdBook/> for the full project.

## License

mdBook is licensed under the Mozilla Public License v2.0 ([LICENSE](LICENSE)).
