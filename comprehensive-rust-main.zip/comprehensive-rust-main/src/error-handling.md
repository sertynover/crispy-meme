# Error Handling

Error handling in Rust is done using explicit control flow:

* Functions that can have errors list this in their return type,
* There are no exceptions.

