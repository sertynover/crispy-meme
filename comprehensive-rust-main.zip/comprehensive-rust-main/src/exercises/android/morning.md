# Exercises

This is a group exercise: We will look at one of the projects you work with and
try to integrate some Rust into it. Some suggestions:

* Call your AIDL service with a client written in Rust.

* Move a function from your project to Rust and call it.

<details>

No solution is provided here since this is open-ended: it relies on someone in
the class having a piece of code which you can turn in to Rust on the fly.

</details>
