# Day 1: Afternoon Exercises

We will look at two things:

* The Luhn algorithm,

* An exercise on pattern matching.

<details>

After looking at the exercises, you can look at the [solutions] provided.

[solutions]: solutions-afternoon.md

</details>
