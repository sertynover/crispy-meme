# Day 1 Afternoon Exercises

## Luhn Algorithm

([back to exercise](luhn.md))

```rust
{{#include luhn.rs:solution}}
```

## Pattern matching

```rust
{{#include pattern-matching.rs:solution}}
```
