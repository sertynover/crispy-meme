# Day 3 Afternoon Exercises

## Safe FFI Wrapper

([back to exercise](safe-ffi-wrapper.md))

```rust
{{#include safe-ffi-wrapper.rs:solution}}
```
