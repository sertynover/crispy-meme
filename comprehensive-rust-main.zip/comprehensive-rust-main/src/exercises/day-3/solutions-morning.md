# Day 3 Morning Exercise

## Drawing A Simple GUI

([back to exercise](simple-gui.md))

```rust
{{#include simple-gui.rs:solution}}
```

## Points and Polygons

([back to exercise](points-polygons.md))

```rust
{{#include points-polygons.rs:solution}}
```
