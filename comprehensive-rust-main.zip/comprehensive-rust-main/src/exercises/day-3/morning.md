# Day 3: Morning Exercises

We will design a classical GUI library using traits and trait objects.

We will also look at enum dispatch with an exercise involving points and polygons.

<details>

After looking at the exercises, you can look at the [solutions] provided.

[solutions]: solutions-morning.md

</details>
