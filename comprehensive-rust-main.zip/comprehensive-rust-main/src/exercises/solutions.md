# Solutions

You will find solutions to the exercises on the following pages.

Feel free to ask questions about the solutions [on
GitHub](https://github.com/google/comprehensive-rust/discussions). Let us know
if you have a different or better solution than what is presented here.
