# Concurrency Morning Exercise

## Dining Philosophers

([back to exercise](dining-philosophers.md))

```rust
{{#include dining-philosophers.rs:solution}}
```

## Link Checker

([back to exercise](link-checker.md))

```rust,compile_fail
{{#include link-checker.rs:solution}}
```
