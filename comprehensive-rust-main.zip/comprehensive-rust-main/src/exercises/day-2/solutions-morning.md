# Day 2 Morning Exercises

## Designing a Library

([back to exercise](book-library.md))

```rust
{{#include book-library.rs:solution}}
```

## Health Statistics

([back to exercise](health-statistics.md))

```rust
{{#include ../../../third_party/rust-on-exercism/health-statistics.rs:solution}}
```
