# Day 2: Morning Exercises

We will look at implementing methods in two contexts:

* Storing books and querying the collection

* Keeping track of health statistics for patients

<details>

After looking at the exercises, you can look at the [solutions] provided.

[solutions]: solutions-morning.md

</details>
