# Day 2: Afternoon Exercises

The exercises for this afternoon will focus on strings and iterators.

<details>

After looking at the exercises, you can look at the [solutions] provided.

[solutions]: solutions-afternoon.md

</details>
