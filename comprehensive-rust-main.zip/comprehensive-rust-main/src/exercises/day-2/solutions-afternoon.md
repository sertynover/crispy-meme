# Day 2 Afternoon Exercises

## Strings and Iterators

([back to exercise](strings-iterators.md))

```rust
{{#include strings-iterators.rs:solution}}
```
