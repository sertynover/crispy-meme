# Bare Metal Rust Afternoon

## RTC driver

([back to exercise](rtc.md))

_main.rs_:

```rust,compile_fail
{{#include rtc/src/main.rs:solution}}
```

_pl031.rs_:

```rust
{{#include rtc/src/pl031.rs:solution}}
```
