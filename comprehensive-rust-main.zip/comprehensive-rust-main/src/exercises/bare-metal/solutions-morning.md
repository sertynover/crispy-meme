# Bare Metal Rust Morning Exercise

## Compass

([back to exercise](compass.md))

```rust,compile_fail
{{#include compass/src/main.rs:solution}}
```
