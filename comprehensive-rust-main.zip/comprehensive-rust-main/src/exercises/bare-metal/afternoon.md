# Exercises

We will write a driver for the PL031 real-time clock device.

<details>

After looking at the exercises, you can look at the [solutions] provided.

[solutions]: solutions-afternoon.md

</details>
