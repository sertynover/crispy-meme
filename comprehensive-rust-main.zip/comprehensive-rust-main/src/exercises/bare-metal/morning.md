# Exercises

We will read the direction from an I2C compass, and log the readings to a serial port.

<details>

After looking at the exercises, you can look at the [solutions] provided.

[solutions]: solutions-morning.md

</details>
