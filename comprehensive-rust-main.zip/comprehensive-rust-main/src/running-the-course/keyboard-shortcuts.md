# Keyboard Shortcuts

There are several useful keyboard shortcuts in mdBook:

* <kbd>Arrow-Left</kbd>: Navigate to the previous page.
* <kbd>Arrow-Right</kbd>: Navigate to the next page.
* <kbd>Ctrl + Enter</kbd>: Execute the code sample that has focus.
* <kbd>s</kbd>: Activate the search bar.
