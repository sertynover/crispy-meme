# Generics

Rust support generics, which lets you abstract algorithms or data structures
(such as sorting or a binary tree)
over the types used or stored.
