# Thanks!

_Thank you for taking Comprehensive Rust 🦀!_ We hope you enjoyed it and that it
was useful.

We've had a lot of fun putting the course together. The course is not perfect,
so if you spotted any mistakes or have ideas for improvements, please get in
[contact with us on
GitHub](https://github.com/google/comprehensive-rust/discussions). We would love
to hear from you.
