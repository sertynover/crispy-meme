# Novel Control Flow

Rust has a few control flow constructs which differ from other languages. They
are used for pattern matching:

- `if let` expressions
- `while let` expressions
- `match` expressions
