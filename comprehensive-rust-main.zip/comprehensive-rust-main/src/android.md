# Welcome to Rust in Android

Rust is supported for native platform development on Android. This means that
you can write new operating system services in Rust, as well as extending
existing services.

> We will attempt to call Rust from one of your own projects today. So try to
> find a little corner of your code base where we can move some lines of code to
> Rust. The fewer dependencies and "exotic" types the better. Something that
> parses some raw bytes would be ideal.
