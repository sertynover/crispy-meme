# Useful crates

We'll go over a few crates which solve some common problems in bare-metal programming.
