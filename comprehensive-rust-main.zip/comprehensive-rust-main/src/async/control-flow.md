# Futures Control Flow

Futures can be combined together to produce concurrent compute flow graphs. We
have already seen tasks, that function as independent threads of execution.

- [Join](control-flow/join.md)
- [Select](control-flow/select.md)
