# Create a C library

_interoperability/c/libbirthday/Android.bp_:

```javascript
{{#include c/libbirthday/Android.bp:libbirthday}}
```

_interoperability/c/libbirthday/libbirthday.h_:

```c
{{#include c/libbirthday/libbirthday.h}}
```

_interoperability/c/libbirthday/libbirthday.c_:

```c
{{#include c/libbirthday/libbirthday.c}}
```

