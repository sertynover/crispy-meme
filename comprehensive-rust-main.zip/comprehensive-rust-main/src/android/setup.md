# Setup

We will be using an Android Virtual Device to test our code. Make sure you have
access to one or create a new one with:

```shell
source build/envsetup.sh
lunch aosp_cf_x86_64_phone-userdebug
acloud create
```

Please see the [Android Developer
Codelab](https://source.android.com/docs/setup/start) for details.
