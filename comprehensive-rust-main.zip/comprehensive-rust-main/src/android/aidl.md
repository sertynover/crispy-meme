# AIDL

The [Android Interface Definition Language
(AIDL)](https://developer.android.com/guide/components/aidl) is supported in Rust:

* Rust code can call existing AIDL servers,
* You can create new AIDL servers in Rust.
