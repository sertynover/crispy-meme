# Testing

Rust and Cargo come with a simple unit test framework:

* Unit tests are supported throughout your code.

* Integration tests are supported via the `tests/` directory.
